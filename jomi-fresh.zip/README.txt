Jomi Fresh — Ready-to-upload website
Files included:
- index.html, about.html, menu.html, contact.html
- css/style.css
- js/main.js
- assets/logo.svg (placeholder logo you can replace)
- assets/*.svg (placeholder images)
How to use:
1. Download and unzip the folder.
2. Open files locally to preview (open index.html).
3. To publish on GitHub Pages:
   - Create a GitHub repo (e.g., jomi-fresh).
   - Upload the contents of this folder to the repo root.
   - In GitHub repo Settings → Pages → Deploy from branch → select main branch / root.
   - Your site will be available at: https://your-username.github.io/repo-name
Replace logo and product images:
- Replace files in assets/ with your images (keep names or update image src paths in HTML).
Contact:
- If you want me to customize text, prices, or replace the placeholder logo with your uploaded logo now, tell me and I'll update the package.
