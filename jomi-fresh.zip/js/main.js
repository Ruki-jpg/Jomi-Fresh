// Simple JS for nav toggle and fake contact submission
document.addEventListener('DOMContentLoaded', function(){
  const btn = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  if(btn){
    btn.addEventListener('click', ()=> {
      if(nav.style.display === 'flex') nav.style.display = '';
      else nav.style.display = 'flex';
      nav.style.flexDirection = 'column';
      nav.style.gap = '0.6rem';
      nav.style.alignItems = 'flex-start';
    });
  }
});

function submitForm(e){
  e.preventDefault();
  const msg = document.getElementById('formMessage');
  msg.textContent = 'Thank you! Your message was received. (This is a demo — connect a real form handler to send messages.)';
  e.target.reset();
}
